# Especificações de Imagens - Artigo 11

## Artigo 11

As imagens devem ser geradas profissionalmente em formato PNG (300 DPI) seguindo as especificações abaixo.

---

## Capa (capa.png)

**Status:** ✅ Gerada

A imagem de capa deve representar o tema principal do artigo de forma visual e atraente.

---

## Figura 1 (figura1.png)

**Contexto do Artigo:** Ver artigo para mais detalhes

---

## Figura 2 (figura2.png)

**Contexto do Artigo:** Ver artigo para mais detalhes

---

## Figura 3 (figura3.png)

**Contexto do Artigo:** Ver artigo para mais detalhes

---

## Figura 4 (figura4.png)

**Contexto do Artigo:** Ver artigo para mais detalhes

---

## Guia de Geração

1. **Ferramenta Recomendada:** Qualquer plataforma de design (Figma, Adobe XD, Canva Pro, etc.)
2. **Formato:** PNG (mínimo 1200x800px, 300 DPI para qualidade profissional)
3. **Paleta de Cores:** 
   - Azul profissional: #2C5282
   - Verde: #38A169
   - Vermelho: #E53E3E
   - Cinza: #718096
   - Fundo claro: #F7FAFC

4. **Tipografia:** Sans-serif (Arial, Helvetica, ou similar)

---

## Status de Geração

- [x] Capa
- [ ] Figura 1
- [ ] Figura 2
- [ ] Figura 3
- [ ] Figura 4

**Última Atualização:** 2025-12-05
