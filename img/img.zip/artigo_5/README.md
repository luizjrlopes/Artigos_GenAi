# Especificações de Imagens - Artigo 5

## Artigo 5

As imagens devem ser geradas profissionalmente em formato PNG (300 DPI) seguindo as especificações abaixo.

---

## Capa (capa.png)

**Status:** ✅ Gerada

A imagem de capa deve representar o tema principal do artigo de forma visual e atraente.

---

## Figura 1 (figura1.png)

**Descrição:** Figura 1: Fluxo de trabalho com LLM como copiloto: Contexto → Geração → Revisão → Produção.

**Contexto do Artigo:**

## 3. Conceitos Fundamentais Para usar essas ferramentas profissionalmente, precisamos dominar três conceitos:

---

## Figura 2 (figura2.png)

**Descrição:** Figura 2: Comparação entre modos de uso de LLM (Local, Enterprise, Public).

**Contexto do Artigo:**

## 4. Mão na Massa: Exemplo Prático

---

## Figura 3 (figura3.png)

**Descrição:** Figura 3: Três casos práticos de LLM como copiloto: Refatoração, Testes e SQL.

**Contexto do Artigo:**

## 5. Métricas, Riscos e Boas Práticas

---

## Figura 4 (figura4.png)

**Descrição:** Figura 4: Ciclo iterativo de refinamento com LLM.

**Contexto do Artigo:**

## 6. Evidence & Exploration Um experimento para rodar no seu time (**Pair Programming AI**):

---

## Guia de Geração

1. **Ferramenta Recomendada:** Qualquer plataforma de design (Figma, Adobe XD, Canva Pro, etc.)
2. **Formato:** PNG (mínimo 1200x800px, 300 DPI para qualidade profissional)
3. **Paleta de Cores:** 
   - Azul profissional: #2C5282
   - Verde: #38A169
   - Vermelho: #E53E3E
   - Cinza: #718096
   - Fundo claro: #F7FAFC

4. **Tipografia:** Sans-serif (Arial, Helvetica, ou similar)

---

## Status de Geração

- [x] Capa
- [ ] Figura 1
- [ ] Figura 2
- [ ] Figura 3
- [ ] Figura 4

**Última Atualização:** 2025-12-05
