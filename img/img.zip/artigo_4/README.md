# Especificações de Imagens - Artigo 4

## Artigo 4

As imagens devem ser geradas profissionalmente em formato PNG (300 DPI) seguindo as especificações abaixo.

---

## Capa (capa.png)

**Status:** ✅ Gerada

A imagem de capa deve representar o tema principal do artigo de forma visual e atraente.

---

## Figura 1 (figura1.png)

**Descrição:** Figura 1: Árvore de decisão para escolher entre Prompt Engineering, RAG e Fine-Tuning.

**Contexto do Artigo:**

## 3. Conceitos Fundamentais Antes de codar, precisamos alinhar as definições:

---

## Figura 2 (figura2.png)

**Descrição:** Figura 2: Tabela comparativa entre Prompt Engineering, RAG e Fine-Tuning.

**Contexto do Artigo:**

## 4. Mão na Massa: Exemplo Prático Vamos resolver os cenários propostos com a arquitetura ideal:

---

## Figura 3 (figura3.png)

**Descrição:** Figura 3: Arquitetura de solução para cada cenário (A: RAG, B: Fine-Tuning SLM, C: Fine-Tuning Persona).

**Contexto do Artigo:**

## 5. Métricas, Riscos e Boas Práticas

---

## Figura 4 (figura4.png)

**Descrição:** Figura 4: Dashboard de métricas para avaliar Fine-Tuning vs Baseline.

**Contexto do Artigo:**

## 6. Evidence & Exploration Um experimento valioso para seu time de engenharia:

---

## Guia de Geração

1. **Ferramenta Recomendada:** Qualquer plataforma de design (Figma, Adobe XD, Canva Pro, etc.)
2. **Formato:** PNG (mínimo 1200x800px, 300 DPI para qualidade profissional)
3. **Paleta de Cores:** 
   - Azul profissional: #2C5282
   - Verde: #38A169
   - Vermelho: #E53E3E
   - Cinza: #718096
   - Fundo claro: #F7FAFC

4. **Tipografia:** Sans-serif (Arial, Helvetica, ou similar)

---

## Status de Geração

- [x] Capa
- [ ] Figura 1
- [ ] Figura 2
- [ ] Figura 3
- [ ] Figura 4

**Última Atualização:** 2025-12-05
