# 📊 Especificações de Imagens - Artigo 3: RAG com Cardápios

## Artigo: "RAG (Retrieval-Augmented Generation) explicado com um exemplo de cardápio"

Este documento contém **4 prompts detalhados** para criar cada figura. Use-os como briefing visual para gerar as imagens profissionalmente.

---

## 🎨 Paleta de Cores Padrão

```
Azul Profissional:    #2C5282
Verde Sucesso:        #38A169
Vermelho/Erro:        #E53E3E
Cinza Escuro:         #718096
Cinza Claro:          #E2E8F0
Branco:               #FFFFFF
Amarelo Destaque:     #ECC94B
Fundo Claro:          #F7FAFC
```

---

## 📐 Especificações Técnicas Gerais

- **Formato:** PNG (sem fundo ou fundo branco #F7FAFC)
- **Dimensões:** Mínimo 1200x800px (landscape)
- **Resolução:** 300 DPI
- **Tipografia:** Sans-serif (Arial, Helvetica, Roboto, Inter)
- **Estilo:** Limpo, minimalista, profissional
- **Consistência:** Usar as mesmas cores e fontes em todas as 4 figuras

---

## 📋 FIGURA 1: Fluxo RAG

### Título

**"Fluxo RAG: O ciclo de Recuperação e Geração"** ou **"Arquitetura RAG Simplificada"**

### Descrição Executiva

Uma figura que mostra o fluxo de dados na arquitetura RAG: Recuperação (Retrieval) antes da Geração. Este é o **passo-a-passo visual** de como o sistema RAG funciona.

### Prompt Detalhado

Crie um **diagrama de fluxo horizontal** mostrando o ciclo RAG em 4 etapas principais:

**Elementos obrigatórios:**

1. **Ícone/Caixa 1 - PERGUNTA DO USUÁRIO**

   - Ícone: Balão de fala ou ícone de usuário
   - Texto: "1. Pergunta: 'Algo vegetariano barato?'"
   - Cor: Azul profissional (#2C5282)

2. **Ícone/Caixa 2 - EMBEDDING + BUSCA VETORIAL**

   - Ícone: Símbolo de vetores/números (3 ou 4 pontos com linhas)
   - Texto: "2. Converter em Vetor + Buscar no VectorDB"
   - Cor: Verde sucesso (#38A169)
   - Detalhe: Mostrar um pequeno "espaço vetorial" com pontos representando os itens do cardápio

3. **Ícone/Caixa 3 - CONTEXTO RECUPERADO**

   - Ícone: Banco de dados ou documento
   - Texto: "3. Recuperar Contexto Relevante"
   - Cor: Amarelo destaque (#ECC94B)
   - Detalhe: Mostrar alguns itens recuperados (ex: "Salada Caesar - R$ 22")

4. **Ícone/Caixa 4 - RESPOSTA GERADA**
   - Ícone: LLM ou IA (cérebro/estrela)
   - Texto: "4. Gerar Resposta com Contexto"
   - Cor: Vermelho/destaque (#E53E3E)
   - Detalhe: Mostrar a resposta: "Temos Salada Caesar (R$ 22,00)"

**Setas de conexão:**

- Setas direcionadas conectando as 4 caixas horizontalmente
- Cor das setas: Cinza escuro (#718096)
- Pode haver uma seta tracejada voltando do passo 4 para o 1 (indicando loop contínuo)

**Estilo:**

- Cada caixa tem um gradiente suave das cores indicadas
- Ícones simples e reconhecíveis
- Boa legibilidade mesmo em tamanho pequeno
- Evitar texto muito pequeno (mínimo 12pt)

**Analogia Visual:**
Semelhante ao fluxo de um pipeline DevOps ou arquitetura de sistema.

---

## 📋 FIGURA 2: Espaço Vetorial

### Título

**"Espaço Vetorial: Proximidade Semântica"** ou **"Como Embeddings Organizam o Conhecimento"**

### Descrição Executiva

Uma visualização simplificada do espaço vetorial em 2D/3D mostrando como itens semanticamente similares ficam próximos no espaço vetorial. Itens do cardápio agrupados por similaridade.

### Prompt Detalhado

Crie um **gráfico de dispersão 2D ou 3D** representando um espaço vetorial com pontos/bolinhas coloridas:

**Elementos obrigatórios:**

1. **Eixos do Gráfico**

   - Eixo X: "Dimensão 1: Tipo (Proteína ←→ Vegetal)"
   - Eixo Y: "Dimensão 2: Peso/Leveza (Pesado ←→ Leve)"
   - Opcional: Um eixo Z para 3D (cor/sabor)
   - Cor dos eixos: Cinza claro (#E2E8F0)

2. **Cluster 1 - PROTEÍNAS/CARNES (Canto inferior direito)**

   - Itens: X-Bacon, Hambúrguer, Picanha
   - Cor: Vermelho (#E53E3E) ou tom quente
   - Label opcional: "Pesado & Proteína"

3. **Cluster 2 - SALADAS/LEVE (Canto superior esquerdo)**

   - Itens: Salada Caesar, Wrap de Cogumelos, Salada Grega
   - Cor: Verde (#38A169) ou tom fresco
   - Label opcional: "Leve & Vegetal"

4. **Cluster 3 - INTERMEDIÁRIO (Centro)**

   - Itens: Pizza Margherita, Pasta Vegetariana
   - Cor: Amarelo/Laranja (#ECC94B) ou tom neutro

5. **Proximidade Visual**
   - Pontos no mesmo cluster estão **próximos** um do outro
   - Pontos em clusters diferentes estão **distantes**
   - Pode usar sombras/halos para indicar proximidade

**Destaque especial:**

- Adicionar uma linha pontilhada mostrando a "pergunta do usuário" (ex: "Algo vegetariano barato?") como um vetor se aproximando do cluster correto (saladas leve)

**Estilo:**

- Fundo claro (#F7FAFC)
- Cada ponto tem um rótulo (nome do item)
- Pode ser 2D simples ou 3D se preferir mais impacto visual
- Sem poluição visual; máximo 8-10 itens no diagrama

**Analogia Visual:**
Similar a um mapa de calor ou scatterplot científico, mas amigável e interpretável.

---

## 📋 FIGURA 3: Comparação RAG vs Fine-Tuning

### Título

**"RAG vs Fine-Tuning: Qual Usar?"** ou **"Abordagens Comparadas"**

### Descrição Executiva

Uma comparação visual clara entre RAG e Fine-Tuning usando a tabela do artigo. Pode ser uma tabela redesenhada visualmente ou um infográfico tipo "vs".

### Prompt Detalhado

Crie um **infográfico "vs" dividido em 2 colunas** representando RAG e Fine-Tuning:

**Lado Esquerdo - RAG:**

- **Ícone Destaque:** Livro aberto com marcador (representa consultar)
- **Cor Tema:** Verde (#38A169)
- **Dados a mostrar:**
  - ✅ Fatos novos (preços, itens, estoque)
  - ✅ Atualização imediata
  - ✅ Baixa alucinação
  - ✅ Custo por token
  - ✅ Ideal para Delivery
- **Analogia:** "Prova COM consulta"

**Lado Direito - Fine-Tuning:**

- **Ícone Destaque:** Livro fechado (representa estudar/memorizar)
- **Cor Tema:** Vermelho (#E53E3E)
- **Dados a mostrar:**
  - ❌ Padrões (estilo, tom)
  - ❌ Atualização lenta
  - ⚠️ Média alucinação
  - ❌ Custo de treino
  - ❌ Inviável para dados dinâmicos
- **Analogia:** "Prova SEM consulta (decorar)"

**Elementos de Comparação:**

- Cada critério em uma linha horizontal
- Ícones visuais (✅, ❌, ⚠️) para rápida leitura
- Cores contrastantes (verde vs vermelho)
- Setas ou indicadores mostrando qual é melhor em cada caso

**Estilo:**

- Design moderno tipo infográfico
- Boa hierarquia visual
- Fácil de scanear rapidamente
- Sem texto muito denso; usar bullets e ícones

**Opcional:**

- Adicionar um "Veredito Final" em destaque na base: "✅ RAG é Ideal para Delivery"

---

## 📋 FIGURA 4: Métricas da Tríade RAG

### Título

**"A Tríade RAG: Três Pilares de Qualidade"** ou **"Medindo a Qualidade do RAG"**

### Descrição Executiva

Uma visualização das 3 métricas essenciais de qualidade para avaliar um sistema RAG: Context Relevance, Groundedness e Answer Relevance. Pode ser triangular, circular ou 3 colunas.

### Prompt Detalhado

Crie uma **figura com 3 pilares/componentes** mostrando as 3 métricas principais:

**Estrutura Visual Options:**

- **Opção 1 (Triângulo):** Um triângulo com cada vértice representando uma métrica
- **Opção 2 (3 Colunas):** Três colunas lado-a-lado
- **Opção 3 (Círculo):** Um círculo dividido em 3 seções

**Métrica 1 - CONTEXT RELEVANCE (Precisão da Busca)**

- **Cor:** Azul (#2C5282)
- **Ícone:** Alvo ou busca
- **Pergunta Exemplo:** "Quero algo vegano"
- **Bom:** ✅ Sistema traz "Hambúrguer de Soja"
- **Ruim:** ❌ Sistema traz "Picanha"
- **Objetivo:** Evitar poluir prompt com dados irrelevantes

**Métrica 2 - GROUNDEDNESS (Fidelidade aos Dados)**

- **Cor:** Verde (#38A169)
- **Ícone:** Âncora ou corrente (dados enraizados)
- **Exemplo:** Contexto diz "R$ 50" mas IA responde "R$ 40"
- **Erro:** ❌ Alucinação - IA ignorou contexto
- **Objetivo:** Resposta 100% ancorada nos dados recuperados

**Métrica 3 - ANSWER RELEVANCE (Utilidade)**

- **Cor:** Amarelo/Laranja (#ECC94B)
- **Ícone:** Caixa de resposta ou conversação
- **Exemplo:** Pergunta "Tem Coca?" → Resposta "Temos Pepsi e Guaraná"
- **Bom:** ✅ Respondeu a dúvida (mesmo que negativa)
- **Objetivo:** Resposta direta e útil ao usuário

**Conectividade:**

- As 3 métricas estão conectadas (simbolizando que todas são importantes)
- Centro com label: "Sistema RAG Saudável"

**Estilo:**

- Cada métrica tem seu ícone e cor distintos
- Descrições sucintas sob cada métrica
- Exemplos visuais pequenos de "bom" vs "ruim"
- Design moderno e educativo

---

## ✅ Checklist de Conclusão

Marque conforme as figuras forem criadas:

- [x] Capa (capa.png) - Já gerada
- [ ] **Figura 1:** Fluxo RAG (figura1.png)
- [ ] **Figura 2:** Espaço Vetorial (figura2.png)
- [ ] **Figura 3:** RAG vs Fine-Tuning (figura3.png)
- [ ] **Figura 4:** Tríade RAG - Métricas (figura4.png)

---

## 📌 Instruções Finais

1. **Leia os prompts acima** com atenção
2. **Use a paleta de cores** consistentemente
3. **Mantenha o estilo** profissional e limpo
4. **Valide legibilidade** em tamanho pequeno (como aparecerão nos artigos)
5. **Exporte em PNG** de alta qualidade (300 DPI)
6. **Nomei os arquivos** exatamente como: `figura1.png`, `figura2.png`, `figura3.png`, `figura4.png`

---

**Data de Criação:** 2025-12-05  
**Artigo:** 3 - RAG com Cardápios  
**Status:** Aguardando criação de figuras 1-4
